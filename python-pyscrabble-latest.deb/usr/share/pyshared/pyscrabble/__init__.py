'''

Welcome to the pyscrabble API.

@author: U{Kevin Conaway<mailto:kevin.a.conaway@gmail.com>}

'''