'''
The GUI package contains all GTK+ code for windowing.
'''